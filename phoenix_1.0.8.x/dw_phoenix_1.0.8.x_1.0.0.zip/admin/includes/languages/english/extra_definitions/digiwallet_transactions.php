<?php
/**
 Digiwallet module class for Zencart
 (C) Copyright Yellow Melon B.V. 2013
 */
define('BOX_TOOLS_DIGIWALLET_TRANSACTIONS', 'Digiwallet Transactions');
